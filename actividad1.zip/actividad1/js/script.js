alert ('Alerta de ejemplo de javascript');
//definicion de variables 

function suma(){
    //let y = document.getElementById("suma")
    var numero1 = 5;
    var numero2 = 6;
    var suma = numero1 +numero2;
    console.log(suma);
    //y = document.write(suma)    
}
suma();



function ccolor(){
    let x = document.getElementById("demo");
    x.style.fontSize = "25px";
    x.style.color="red";
    
}